
package ServletProyect;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author brawd
 */
public class ProyectServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Redirect("../Web Pages/index.jsp")
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response, redirect(pagina))
            throws ServletException, IOException {
        
        String usuario = "root";
        String password = "";
        String url = "jdbc:mysql://localhost:3306/quickez";
        
        Connection conexion;
        Statement statement;
        ResultSet rs;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProyectServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String Name = request.getParameter("Name");
        String Document = request.getParameter("Document");
        
        try{
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();
            
            statement.executeQuery("SELECT * FROM CLIENTES");
            //traer la tabla clientes de la base de datos quickez
            
            String longitud = getInt("num_documento").lenght;
            String pass = getInt("num_documento");
            String name = getString("name_cliente");

            for(int i=0; i < String longitud; i++){
                
                if(Document.equals(pass) && Name.equals(name)){
                    rs = redirect(index.jsp);
                    rs.next();

                }else{
                    rs = redirect("../Web Pages/registrarse.jsp");
                    rs.next();
                }
            }         
        } catch (SQLException ex){
            Logger.getLogger(ProyectServlet.class.getName()).log(Level.SEVERE, null, ex);

        }
        
        
        processRequest(request, response, "../Web Pages/registrarse.jsp");
    }

    //............
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response, HttpServletRedirect pagina )
            throws ServletException, IOException {
        
        String usuario = "root";
        String password = "";
        String url = "jdbc:mysql://localhost:3306/quickez";
        
        Connection conexion;
        Statement statement;
        ResultSet rs;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProyectServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        String User = request.getParameter("Usuario");
        String Documento = request.getParameter("Documento");
        String Email = request.getParameter("Email");
        
        try{
            conexion = DriverManager.getConnection(url, usuario, password);
            statement = conexion.createStatement();
            
            //insertar datos con comandos MYSQL
            statement.executeUpdate("INSERT INTO CLIENTES(NUM_DOCUMENTO, NAME_CLIENTE, EMAIL) VALUES(User, Documento, Email)");

            //rs = statement.executeQuery("SELECT * FROM CLIENTES");
            //traer la tabla clientes de la base de datos quickez
            rs = redirect(".../Web Pages/index.jpg");
            rs.next();

            
            
        } catch (SQLException ex){
            Logger.getLogger(ProyectServlet.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
        processRequest(request, response, ".../Web Pages/index.jsp");
}
